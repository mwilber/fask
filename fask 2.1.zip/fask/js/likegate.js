$('body').bind('AuthorizedUser', function(event, authObj) {
	LikeGate();
});